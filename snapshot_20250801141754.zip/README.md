# GinieSystem Automated Deployment

This repository contains scripts and tools to bootstrap the **GinieSystem** from scratch on macOS.

## Components

- **install.sh** – Universal installer for macOS. Installs required dependencies (Homebrew, Python), clones this repository into `~/.ginie-system`, creates a Python virtual environment and installs Python dependencies.
- **freeze_kill.sh** – Utility for freezing the runtime state and forcefully terminating GinieSystem processes. Use `./freeze_kill.sh freeze` to create a snapshot or `./freeze_kill.sh kill` to stop the system.
- **self_test.sh** – Runs a series of checks to ensure GinieSystem is correctly installed. Attempts to auto‑heal by recreating missing components if necessary.
- **generate_qr.py** – Python script that generates a QR code of the installation command, produces a ZIP snapshot of the repository, computes a SHA‑256 hash, and encrypts the snapshot into a vault file.
- **requirements.txt** – Lists Python dependencies required by the scripts.

## Usage

1. Run the installer:

   ```sh
   bash install.sh
   ```

2. To create a snapshot or kill processes:

   ```sh
   bash freeze_kill.sh freeze
   bash freeze_kill.sh kill
   ```

3. To perform a self-test:

   ```sh
   bash self_test.sh
   ```

4. To generate a QR code, package snapshot and encrypt backup:

   ```sh
   python3 generate_qr.py
   ```

This project is part of the GinieSystem initiative to build a self‑healing AI operating system with real‑time monitoring, economic earning, child safety and full automation.